
#include "population.h"
#include "biblio.h"
#include "filemanager.h"
#include "advanced.h"
#include "export_html.h"

int main() {
  // MENU
  
  int choix=0;
  int choixFichier=0;
  int tailleTab= TAB_MAX40;
  char* fichCSV= "40.csv"; 
  la_personne* tabAncetre[7];    //2^3-1
  la_personne* tab200[TAB_MAX200]= {0};
  la_personne* tab40[TAB_MAX40]= {0};
  la_personne** tab = tab40;
  mkdir("dossierHTML",0777);
  while(true){
    printf("\n\n~~~~~~~~~~~MENU~~~~~~~~~~~\n");
    printf("\t1) Notice\n");
    printf("\t2) Choix du fichier\n");
    printf("\t3) Ancetre\n");
    printf("\t4) Fratrie\n");
    printf("\t5) Purge du dossierHTML\n");
    printf("\t6) Quitter\n");
    printf("~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");
    
    do {
      printf("\tVotre choix > ");
      scanf("%d",&choix);
      if (choix > 6 || choix < 0)
        choix = 0;
    } while(choix==0);

    long int positionInCSV = 0;
    for(int i = 0; i< tailleTab; i++) {  
      tab[i] = read_CSV(tab[0], &positionInCSV, fichCSV);
    }   
    linkPopulation(tab, tailleTab);
    switch (choix){
      case 1 :

            break;
      case 2 :
            printf("\nQuel fichier choississez vous ?\n\n\t1) Fichier 40.csv\n\t2) Fichier 200.csv\n\n\tVotre choix de fichier > ");
            scanf("%d", &choixFichier);
            
            if(choixFichier == 1) {
              fichCSV= "40.csv";
              tab = tab40;
              tailleTab = TAB_MAX40;
            } else {
              fichCSV= "200.csv";
              tab = tab200;
              tailleTab = TAB_MAX200;
            }
            
            break;
            
      case 3 :
            printf("");
            creationCSS();                   // sert à pouvoir initialiser la personne dans le case 3
            la_personne* tabAncetre[7];    //2^3-1
            long int position;               
            
            ancetre(tab, tabAncetre, tailleTab);
            char* fich = "dossierHTML/index.html";
            
            long int positionInHTML;
            enteteHtml(&positionInHTML,fich);
            titreHTMLPerson(tabAncetre, &positionInHTML);
            finHTML(&positionInHTML, fich);
            
            for (int i=0;i<7;i++) {
              fichePath(tabAncetre[i], &position);
            }
            
            libere(tab, tailleTab);
            
            return 0;
      case 4 :
            printf("");
            creationCSS();
            int compteur = 0;
            la_fratrie* premierFrere = fratrie(tab, tailleTab, &compteur);
            afficheFratrie(premierFrere, &positionInHTML);

            
            //libere(tab, tailleTab);
            //libere(tabFratrie, compteur);
            return 0;
      case 5 : 
            rmdir("dossierHTML");
            //mkdir("dossierHTML",0777);
            break;
      case 6 :
            libere(tab, tailleTab);
            printf("fin"); 
            return 0;
    }
    //printf("\x1b[2J");

  }

  // *** Ancetre sur 2 générations ***
  
  
  long int positionInHTML;
  
  
  
  
  return 0;
}
