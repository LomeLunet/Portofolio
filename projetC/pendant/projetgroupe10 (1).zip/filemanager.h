#ifndef FILE_FILEMANAGER_H
#define FILE_FILEMANAGER_H

#include "biblio.h"
#include "population.h"

la_personne* read_CSV(la_personne* inconu,long int* positionInCSV,char* fich);



#endif