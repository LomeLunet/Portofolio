#ifndef PROJET_BIBLIO_H
#define PROJET_BIBLIO_H

#define TAB_MAX200 201
#define TAB_MAX40 41
#define TAILLE_MAX 25
#define CSV1 "40.csv"


#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>



#endif