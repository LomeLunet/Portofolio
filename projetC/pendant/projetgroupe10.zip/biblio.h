#ifndef PROJET_BIBLIO_H
#define PROJET_BIBLIO_H

//taille max du tableau de 200 personnes du CSV
#define TAB_MAX200 201

//taille max du tableau de 40 personne du CSV
#define TAB_MAX40 41

//taille max
#define TAILLE_MAX 25

//implementation des bibliotheque utilisées
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
//inplemantation des bibliotheque pour le mkdir
#include <sys/stat.h>
#include <sys/types.h>
//#include <unistd.h>



#endif